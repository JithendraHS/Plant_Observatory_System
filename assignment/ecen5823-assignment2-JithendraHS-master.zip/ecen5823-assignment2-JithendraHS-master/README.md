# ecen5823-s25-assignments
Starter code based on Gecko SDK 4.3.2 and GNU ARM v10.2.1

You must have Gecko SDK Version 4.3.2 and GNU ARM v10.2.1 to compile successfully without warnings and errors.

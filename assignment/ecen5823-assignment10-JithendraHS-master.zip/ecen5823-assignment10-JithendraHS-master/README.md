# ecen5823-mesh
Development version - Starter code for A10.

The code for this project originated from:
  https://github.com/SiliconLabs/bluetooth_mesh_stack_features/tree/master
    or
  https://github.com/SiliconLabs/bluetooth_mesh_stack_features.git 
    branch = Master
    
Please see the README files in the server and client sub-directories.

